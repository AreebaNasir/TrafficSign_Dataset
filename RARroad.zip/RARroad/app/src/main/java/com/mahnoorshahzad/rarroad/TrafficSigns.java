package com.mahnoorshahzad.rarroad;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.List;

public class TrafficSigns extends AppCompatActivity {

    RecyclerView rv;
    TrafficSign_adapter adapter;
    RecyclerView.LayoutManager lm;
    List<TrafficSigninfo> trafficsigns;
    ImageView menu,home,settings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_traffic_signs);
        rv = findViewById(R.id.rv);
        trafficsigns = new ArrayList<>();

        trafficsigns.add(new TrafficSigninfo("Stop sign ahead, prepare to Stop.",  R.drawable.stop));
        trafficsigns.add(new TrafficSigninfo("Speed 70 sign ahead, slow down your speed to 70.",  R.drawable.speed));
        trafficsigns.add(new TrafficSigninfo("Give way sign ahead, prepare to give way.",  R.drawable.yield));
        trafficsigns.add(new TrafficSigninfo("Right turn sign ahead, prepare to turn right.",  R.drawable.right_turn));


        lm = new LinearLayoutManager(this);
        adapter = new TrafficSign_adapter(trafficsigns, this);
        rv.setLayoutManager(lm);
        rv.setAdapter(adapter);

        menu= findViewById(R.id.menu);
        home= findViewById(R.id.home);
        settings= findViewById(R.id.settings);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(TrafficSigns.this, startDirecting.class);        // Specify any activity here e.g. home or splash or login etc
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                i.putExtra("EXIT", true);
                startActivity(i);
                finish();
            }
        });

        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1 = new Intent(TrafficSigns.this,Menu.class);
                startActivity(i1);
            }
        });

        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1 = new Intent(TrafficSigns.this,Setting.class);
                startActivity(i1);
            }
        });
    }
}