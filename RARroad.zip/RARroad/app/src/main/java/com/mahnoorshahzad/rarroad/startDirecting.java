package com.mahnoorshahzad.rarroad;

import androidx.appcompat.app.AppCompatActivity;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

public class startDirecting extends AppCompatActivity {

    Button start;
    ImageView menu,home,settings, road;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_directing);

        start= findViewById(R.id.start);
        menu= findViewById(R.id.menu);
        home= findViewById(R.id.home);
        settings= findViewById(R.id.settings);
        road = findViewById(R.id.road);

        final Animation alpha = AnimationUtils.loadAnimation(this,R.anim.alpha);

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                view.startAnimation(alpha);
                Intent i1 = new Intent(startDirecting.this,Direction.class);
                startActivity(i1);
            }
        });

        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1 = new Intent(startDirecting.this,Menu.class);
                startActivity(i1);
            }
        });

        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1 = new Intent(startDirecting.this,Setting.class);
                startActivity(i1);
            }
        });



    }
}