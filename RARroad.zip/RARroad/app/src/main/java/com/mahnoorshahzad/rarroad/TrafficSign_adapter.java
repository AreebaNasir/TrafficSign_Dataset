package com.mahnoorshahzad.rarroad;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class TrafficSign_adapter extends RecyclerView.Adapter<TrafficSign_adapter.MyViewHolder> {

    List<TrafficSigninfo> ls;
    Context c;

    public TrafficSign_adapter(List<TrafficSigninfo> ls, Context c){
        this.c=c;
        this.ls=ls;
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemrow= LayoutInflater.from(c).inflate(R.layout.trafficsign_row,parent,false);
        return new MyViewHolder(itemrow);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        holder.info.setText(ls.get(position).getText());
        holder.signimg.setImageResource(ls.get(position).getImg());
    }

    @Override
    public int getItemCount() {
        return  ls.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView info;
        ImageView signimg;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            signimg=itemView.findViewById(R.id.sign);
            info=itemView.findViewById(R.id.info);
        }
    }
}
