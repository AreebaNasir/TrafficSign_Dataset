package com.mahnoorshahzad.rarroad;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.List;

public class TrafficFacts extends AppCompatActivity {

    RecyclerView rv;
    Trafficinfo_adapter adapter;
    RecyclerView.LayoutManager lm;
    List<Trafficinfo_text> trafficfacts;
    ImageView menu,home,settings;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_traffic_facts);
        rv = findViewById(R.id.rv);
        trafficfacts = new ArrayList<>();

        trafficfacts.add(new Trafficinfo_text("In 2010, a traffic jam on a highway near Beijing kept cars stuck in traffic for more than a week (9-12 days according to different sources."));
        trafficfacts.add(new Trafficinfo_text("The very first traffic lights were a manually operated and gas-lit."));
        trafficfacts.add(new Trafficinfo_text("In 1928, Charles Adler Jr invented traffic lights that could be activated by drivers honking."));
        trafficfacts.add(new Trafficinfo_text("Octagon Is the Universal Shape for Stop Signs Because of Its Low Production cost (cheapest to make."));
        trafficfacts.add(new Trafficinfo_text("Traffic jams result in 5.7 billion person-hours of delay annually in the United States."));
        trafficfacts.add(new Trafficinfo_text("One bus could carry the same number of people as 30 cars, while only occupying the road space of three cars."));
        trafficfacts.add(new Trafficinfo_text("If one in 10 Americans regularly used public transportation, U.S. reliance on foreign oil could decline by more than 40%, or nearly the amount of oil imported from Saudi Arabia each year."));
        trafficfacts.add(new Trafficinfo_text("In London, Cologne, Amsterdam and Brussels, drivers spend more than 50 hours a year in road traffic congestions. This number is even higher in Utrecht, Manchester and Paris: 70 hours."));
        trafficfacts.add(new Trafficinfo_text(" Guinness World Records claims that what happened in China wasn’t the longest traffic congestion in history though. An older jam happened in France, spanning from Lyon to Paris, and is regarded as the biggest congestion ever. It stretched for 175 km and took place on February 16, 1980. The reason is told to be poor weather and a huge number of cars on the French Autoroute."));

        lm = new LinearLayoutManager(this);
        adapter = new Trafficinfo_adapter(trafficfacts, this);
        rv.setLayoutManager(lm);
        rv.setAdapter(adapter);

        menu= findViewById(R.id.menu);
        home= findViewById(R.id.home);
        settings= findViewById(R.id.settings);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(TrafficFacts.this, startDirecting.class);        // Specify any activity here e.g. home or splash or login etc
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                i.putExtra("EXIT", true);
                startActivity(i);
                finish();
            }
        });

        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1 = new Intent(TrafficFacts.this,Menu.class);
                startActivity(i1);
            }
        });

        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1 = new Intent(TrafficFacts.this,Setting.class);
                startActivity(i1);
            }
        });
    }
}