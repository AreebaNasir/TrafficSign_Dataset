package com.mahnoorshahzad.rarroad;

public class Trafficinfo_text
{
    String txt;

    public Trafficinfo_text(String txt) {
        this.txt = txt;
    }

    public String getText() {
        return txt;
    }

    public void setText(String txt) {
        this.txt = txt;
    }

}
