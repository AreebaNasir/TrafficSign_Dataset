package com.mahnoorshahzad.rarroad;

public class TrafficSigninfo {
    String txt;
    private int img;

    public TrafficSigninfo(String txt, int img) {
        this.txt = txt;
        this.img = img;
    }

    public String getText() {
        return txt;
    }

    public void setText(String txt) {
        this.txt = txt;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }


}
