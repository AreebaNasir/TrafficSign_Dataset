package com.mahnoorshahzad.rarroad;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Trafficinfo_adapter  extends RecyclerView.Adapter<Trafficinfo_adapter.MyViewHolder>  {
    List<Trafficinfo_text> ls;
    Context c;

    public Trafficinfo_adapter(List<Trafficinfo_text> ls, Context c){
        this.c=c;
        this.ls=ls;
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemrow= LayoutInflater.from(c).inflate(R.layout.trafficinfo,parent,false);
        return new MyViewHolder(itemrow);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        holder.stmt.setText(ls.get(position).getText());
    }

    @Override
    public int getItemCount() {
        return ls.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView stmt;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            stmt=itemView.findViewById(R.id.stmt);
        }
    }
}
