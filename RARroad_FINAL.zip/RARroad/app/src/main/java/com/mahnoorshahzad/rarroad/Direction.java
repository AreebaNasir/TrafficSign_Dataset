package com.mahnoorshahzad.rarroad;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.ssl.SSLSockets;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Locale;

import android.speech.tts.TextToSpeech;

public class Direction extends AppCompatActivity {

    ImageView home,settings,msgbox;
    TextView dir;
    Handler handler;
    Boolean run = true;
    String label;
    String preLabel="nothing";
    String direction;
    private TextToSpeech tts;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_direction);

        msgbox = findViewById(R.id.msgbox);
        home = findViewById(R.id.home);
        settings = findViewById(R.id.settings);
        dir=findViewById(R.id.ins);

        handler = new Handler();
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1 = new Intent(Direction.this,Setting.class);
                startActivity(i1);
            }
        });

        final Handler handlerr = new Handler();
        handlerr.postDelayed(new Runnable() {
            @Override
            public void run() {
                //Call the Receive() method every 1 second
                Receive();
                handler.postDelayed(this, 100);
            }
        }, 100);  //the time is in miliseconds


        //*****************************************************************************//
        //For text to speech
        tts=new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status==TextToSpeech.SUCCESS)
                {
                    int res=tts.setLanguage(Locale.US);
                    if(res==TextToSpeech.LANG_MISSING_DATA || res==TextToSpeech.LANG_NOT_SUPPORTED)
                    {
                        Log.e("TTS","Language not supported");
                    }
                    else
                    {
                        dir.setEnabled(true);
                    }
                } else{
                    Log.e("TTS","Initialization failed!!!");
                }

            }
        });

    }



    public void Receive()
    {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Log.d(run.toString(), "run: Before creating the socket***************************");
                    Socket s = new Socket("192.168.10.46", 5000);
                    Log.d(run.toString(), "run: After creating the socket***************************");
                    Log.d(run.toString(), "run: Wait for buffer Reader***************************");
                    BufferedReader data = new BufferedReader(new InputStreamReader(s.getInputStream()));
                    final String st = data.readLine();
                    Log.d(run.toString(), "run: Read the line***************************");

                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if(st.trim().length() != 0 )
                            {

                                try { JSONObject ob = new JSONObject(st);
                                    label = ob.getString("label");

                                    if(!label.equalsIgnoreCase(preLabel))
                                    {
                                        //  1. Match the previous label with the new label coming from the model
                                        //and if they are same then do not play the audio because its audio
                                        //has already played as we need to play audio only once for a label
                                        /*if(label.equalsIgnoreCase("0"))
                                        {
                                            Log.d(label, "Speed Sign 30");
                                            direction="Speed Sign 50 ahead, change you speed to 50";
                                            tts.speak(direction,TextToSpeech.QUEUE_FLUSH,null);
                                            preLabel = label;
                                        }*/
                                        if(label.equalsIgnoreCase("1"))
                                        {
                                            Log.d(label, "Speed Sign 50");
                                            direction="Attention! Speed Sign 50 ahead, change your speed to 50";
                                            tts.speak(direction,TextToSpeech.QUEUE_FLUSH,null);
                                            preLabel = label;
                                        }
                                        else if(label.equalsIgnoreCase("2"))
                                        {
                                            Log.d(label, "Yield Sign");
                                            direction="Attention! Yield Sign ahead, prepare to give way";
                                            tts.speak(direction,TextToSpeech.QUEUE_FLUSH,null);
                                            preLabel = label;
                                        }
                                        else if(label.equalsIgnoreCase("3"))
                                        {
                                            Log.d(label, "Stop sign ");
                                            direction="Attention! Stop Sign ahead, Prepare to stop";
                                            tts.speak(direction,TextToSpeech.QUEUE_FLUSH,null);
                                            preLabel = label;
                                        }
                                        else
                                        {
                                            Log.d(label, "Others ");
                                            direction="Attention! Other Traffic Sign ahead";
                                            tts.speak(direction,TextToSpeech.QUEUE_FLUSH,null);
                                            preLabel = label;
                                        }

                                    }


                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                            }
                            else
                            {
                                run = false;

                            }
                            dir.setText(direction);
                            //speak();
                        }
                    });

                    s.close();

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        thread.start();
    }
}