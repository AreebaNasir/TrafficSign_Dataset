package com.mahnoorshahzad.rarroad;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.List;

public class RoadSafety extends AppCompatActivity {

    RecyclerView rv;
    Trafficinfo_adapter adapter;
    RecyclerView.LayoutManager lm;
    List<Trafficinfo_text> trafficfacts;
    ImageView menu,home,settings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_road_safety);
        rv = findViewById(R.id.rv);
        trafficfacts = new ArrayList<>();

        trafficfacts.add(new Trafficinfo_text("Approximately 1.35 million people die in road crashes each year, on average 3,700 people lose their lives every day on the roads."));
        trafficfacts.add(new Trafficinfo_text("More than half of all road traffic deaths occur among vulnerable road users—pedestrians, cyclists, and motorcyclists."));
        trafficfacts.add(new Trafficinfo_text("Road traffic injuries are the leading cause of death among young people aged 5-29. Young adults aged 15-44 account for more than half of all road deaths."));
        trafficfacts.add(new Trafficinfo_text("On average, road crashes cost countries 3% of their gross domestic product."));
        trafficfacts.add(new Trafficinfo_text("Around the world, almost three times more men than women die from road traffic injuries."));
        trafficfacts.add(new Trafficinfo_text("Road traffic injuries are the leading cause of death globally among people aged 15–29 years."));

        lm = new LinearLayoutManager(this);
        adapter = new Trafficinfo_adapter(trafficfacts, this);
        rv.setLayoutManager(lm);
        rv.setAdapter(adapter);

        menu= findViewById(R.id.menu);
        home= findViewById(R.id.home);
        settings= findViewById(R.id.settings);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(RoadSafety.this, startDirecting.class);        // Specify any activity here e.g. home or splash or login etc
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                i.putExtra("EXIT", true);
                startActivity(i);
                finish();
            }
        });

        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1 = new Intent(RoadSafety.this,Menu.class);
                startActivity(i1);
            }
        });

        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1 = new Intent(RoadSafety.this,Setting.class);
                startActivity(i1);
            }
        });
    }
}