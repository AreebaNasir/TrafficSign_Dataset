package com.mahnoorshahzad.rarroad;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class Menu extends AppCompatActivity {

    ImageView back;
    TextView signs,facts,safety;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        back= findViewById(R.id.back);
        signs= findViewById(R.id.signs);
        facts= findViewById(R.id.facts);
        safety= findViewById(R.id.safety);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        signs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1 = new Intent(Menu.this,TrafficSigns.class);
                startActivity(i1);
                finish();
            }
        });

        facts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1 = new Intent(Menu.this,TrafficFacts.class);
                startActivity(i1);
                finish();
            }
        });

        safety.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1 = new Intent(Menu.this,RoadSafety.class);
                startActivity(i1);
                finish();
            }
        });
    }
}