package com.mahnoorshahzad.rarroad;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.List;

public class TrafficFacts extends AppCompatActivity {

    RecyclerView rv;
    Trafficinfo_adapter adapter;
    RecyclerView.LayoutManager lm;
    List<Trafficinfo_text> trafficfacts;
    ImageView menu,home,settings;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_traffic_facts);
        rv = findViewById(R.id.rv);
        trafficfacts = new ArrayList<>();

        trafficfacts.add(new Trafficinfo_text("In 2010, a traffic jam on a highway near Beijing kept cars stuck in traffic for more than a week (9-12 days according to different sources."));
        trafficfacts.add(new Trafficinfo_text("The very first traffic lights were a manually operated and gas-lit."));
        trafficfacts.add(new Trafficinfo_text("In 1928, Charles Adler Jr invented traffic lights that could be activated by drivers honking."));
        trafficfacts.add(new Trafficinfo_text("Octagon Is the Universal Shape for Stop Signs Because of Its Low Production cost (cheapest to make."));

        lm = new LinearLayoutManager(this);
        adapter = new Trafficinfo_adapter(trafficfacts, this);
        rv.setLayoutManager(lm);
        rv.setAdapter(adapter);

        menu= findViewById(R.id.menu);
        home= findViewById(R.id.home);
        settings= findViewById(R.id.settings);

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(TrafficFacts.this, startDirecting.class);        // Specify any activity here e.g. home or splash or login etc
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                i.putExtra("EXIT", true);
                startActivity(i);
                finish();
            }
        });

        menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1 = new Intent(TrafficFacts.this,Menu.class);
                startActivity(i1);
            }
        });

        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i1 = new Intent(TrafficFacts.this,Setting.class);
                startActivity(i1);
            }
        });
    }
}